-- advanced_password_check_test.sql
-- Regression tests for advanced_password_check extension
-- Run with: make installcheck

-- =========================================================================
-- Setup
-- =========================================================================
CREATE EXTENSION IF NOT EXISTS advanced_password_check;

-- Set policy to default values explicitly
SET advanced_password_check.min_length    = 9;
SET advanced_password_check.min_uppercase = 2;
SET advanced_password_check.min_lowercase = 2;
SET advanced_password_check.min_numbers   = 2;
SET advanced_password_check.min_special   = 2;
SET advanced_password_check.min_char_diff = 4;

-- Inspect policy view
SELECT name, setting FROM advanced_password_check_policy ORDER BY name;

-- =========================================================================
-- Test helper role
-- =========================================================================
DROP ROLE IF EXISTS test_apc_user;

-- =========================================================================
-- Test 1: Password too short (7 chars)
-- Expected: ERROR
-- =========================================================================
\echo '--- Test 1: Too short ---'
DO $$
BEGIN
    CREATE ROLE test_apc_user PASSWORD 'Ab1!xy7';
    RAISE EXCEPTION 'UNEXPECTED SUCCESS - should have failed';
EXCEPTION
    WHEN invalid_parameter_value THEN
        RAISE NOTICE 'PASS: short password rejected (%)', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 2: No uppercase letters  (meets all other rules)
-- Expected: ERROR
-- =========================================================================
\echo '--- Test 2: No uppercase ---'
DO $$
BEGIN
    CREATE ROLE test_apc_user PASSWORD 'ab12!!xyz9';
    RAISE EXCEPTION 'UNEXPECTED SUCCESS';
EXCEPTION
    WHEN invalid_parameter_value THEN
        RAISE NOTICE 'PASS: missing uppercase rejected (%)', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 3: No lowercase letters
-- Expected: ERROR
-- =========================================================================
\echo '--- Test 3: No lowercase ---'
DO $$
BEGIN
    CREATE ROLE test_apc_user PASSWORD 'AB12!!XYZ9';
    RAISE EXCEPTION 'UNEXPECTED SUCCESS';
EXCEPTION
    WHEN invalid_parameter_value THEN
        RAISE NOTICE 'PASS: missing lowercase rejected (%)', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 4: Not enough digits (only 1)
-- Expected: ERROR
-- =========================================================================
\echo '--- Test 4: Not enough digits ---'
DO $$
BEGIN
    CREATE ROLE test_apc_user PASSWORD 'ABcd!!xyz1';
    RAISE EXCEPTION 'UNEXPECTED SUCCESS';
EXCEPTION
    WHEN invalid_parameter_value THEN
        RAISE NOTICE 'PASS: missing digits rejected (%)', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 5: Not enough special characters (only 1)
-- Expected: ERROR
-- =========================================================================
\echo '--- Test 5: Not enough special chars ---'
DO $$
BEGIN
    CREATE ROLE test_apc_user PASSWORD 'ABcd12xyz!';
    RAISE EXCEPTION 'UNEXPECTED SUCCESS';
EXCEPTION
    WHEN invalid_parameter_value THEN
        RAISE NOTICE 'PASS: missing special chars rejected (%)', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 6: Valid password - should succeed
-- Password: 'SynxDB@2024#' -> len=12, upper=2, lower=4, digits=4, special=2
-- =========================================================================
\echo '--- Test 6: Valid password ---'
DO $$
BEGIN
    CREATE ROLE test_apc_user PASSWORD 'SynxDB@2024#';
    RAISE NOTICE 'PASS: valid password accepted';
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'FAIL: valid password rejected: %', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 7: Check min_char_diff - too similar to previous
-- Previous password stored, new one barely changes
-- =========================================================================
\echo '--- Test 7: Too similar to previous password ---'
DO $$
BEGIN
    -- Change only 1 character (less than min_char_diff=4)
    ALTER ROLE test_apc_user PASSWORD 'SynxDB@2024$';
    RAISE EXCEPTION 'UNEXPECTED SUCCESS - should be too similar';
EXCEPTION
    WHEN invalid_parameter_value THEN
        RAISE NOTICE 'PASS: similar password rejected (%)', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 8: Valid password change - sufficiently different
-- =========================================================================
\echo '--- Test 8: Valid password change ---'
DO $$
BEGIN
    ALTER ROLE test_apc_user PASSWORD 'NewPass!!99xZ';
    RAISE NOTICE 'PASS: sufficiently different new password accepted';
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'FAIL: %', SQLERRM;
END;
$$;

-- =========================================================================
-- Test 9: Adjust policy at runtime - relax min_length to 6
-- =========================================================================
\echo '--- Test 9: Runtime policy change ---'
SET advanced_password_check.min_length = 6;
SET advanced_password_check.min_uppercase = 1;
SET advanced_password_check.min_lowercase = 1;
SET advanced_password_check.min_numbers = 1;
SET advanced_password_check.min_special = 1;
SET advanced_password_check.min_char_diff = 0;

DO $$
BEGIN
    ALTER ROLE test_apc_user PASSWORD 'Ax1!bc';
    RAISE NOTICE 'PASS: password accepted under relaxed policy';
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'FAIL under relaxed policy: %', SQLERRM;
END;
$$;

-- =========================================================================
-- Cleanup
-- =========================================================================
DROP ROLE IF EXISTS test_apc_user;

\echo '--- All tests complete ---'
